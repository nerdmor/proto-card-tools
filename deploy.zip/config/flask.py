class ProductionConfig():
    ENV = 'prod'
    PROTOCOL = 'https://'
    DOMAIN = 'protocardtools.com'
    PORT = '80'
    OAUTH_REDIRECT_URL = 'https://protocardtools.com/oauth'
    DB_HOSTNAME = 'nerdmor.mysql.pythonanywhere-services.com'
    DB_USERNAME = 'nerdmor'
    DB_PASSWORD = '7Bqjsr3Y6tkLRt'
    DB_DATABASE = 'nerdmor$default'
    CRYTO_KEY = "cMUvJSZdN6nCYRC6j9DtMgTUSIO9hBbVXYRYxFqke5Y="
    JWT_KEY = 'Yqt64w19FhbsBuT9PAQGu2YIwi6ZVzNJwBPPCdYqMVEQihJO7Y9Dh992o59QLwUp'

class DevelopmentConfig():
    ENV = 'dev'
    PROTOCOL = 'http://'
    DOMAIN = '127.0.0.1'
    PORT = '5000'
    OAUTH_REDIRECT_URL = 'http://127.0.0.1:5000/oauth'
    DB_HOSTNAME = '127.0.0.1'
    DB_USERNAME = 'root'
    DB_PASSWORD = ''
    DB_DATABASE = 'nerdmor$default'
    CRYTO_KEY = "H6wYM8tnO2cAiVMGuKqz-DMwPo9-MaXyrgpDXsVvSyw="
    JWT_KEY = 'gBNDC8nQGQO6m7KR1KEEYe6zJvFNGVmITXxh1DqGmBtyAvFOb7gAQ64SDA2O2sXo'